CREATE TABLE IF NOT EXISTS `datos` (

`id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(25) COLLATE utf16_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf16_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE utf16_spanish_ci NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `genero` enum('Femenino','Masculino') COLLATE utf16_spanish_ci NOT NULL,
  `escolaridad` enum('Primaria','Secundaria','Universitario','Posgrado') COLLATE utf16_spanish_ci NOT NULL,
  `estadoCivil` enum('Soltero','Casado','Divorciado','Union Libre') COLLATE utf16_spanish_ci NOT NULL,
  `rutaImagen` varchar(200) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (id)
);testtesttesttesttesttesttesttest